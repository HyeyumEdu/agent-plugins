# SPDX-License-Identifier: Apache-2.0
"""Author Hancom-native TOC and page cross-reference fields.

Emits the exact field contract inferred from an owner-authored
Hancom document (``specs/009-native-toc-xrefs/evidence/
p0-native-toc-xml-contract.md``; gold pair vendored in
``tests/fixtures/m7_toc_gold/``):

* ``<hp:fieldBegin type="TABLEOFCONTENTS">`` + ``TableOfContents:set`` Command
  DSL wrapping generated entry paragraphs (HYPERLINK fields whose single
  ``<hp:t>`` nests the dot-leader ``hp:tab``; page number in the tab's tail),
* ``<hp:fieldBegin type="CROSSREF">`` page references whose cached result is
  the plain ``hp:t`` run between fieldBegin and fieldEnd (Hancom recomputes
  these automatically on edit/save — P0 measured),
* anchors that are plain paragraph ``id`` attributes; TOC-targeted headings
  therefore need document-unique ids (:func:`ensure_paragraph_anchor_id`).

Honest semantics (measured): entry page numbers emitted here are ESTIMATES —
Hancom only recomputes the TOC block on an explicit 차례 새로 고침, which the
P3 oracle triggers and verifies. CROSSREF caches self-heal on edit/save.
The parameter spelling ``Fiexde`` replicates Hancom's own output verbatim.
"""
from __future__ import annotations

import re
from typing import Any, Sequence
from uuid import uuid4

# live section paragraphs are lxml elements — new nodes must match
from lxml import etree as ET

from hwpx.document import HwpxDocument
from hwpx.errors import HwpxValueError
from hwpx.oxml.field_marks import field_type_id

_HP = "{http://www.hancom.co.kr/hwpml/2011/paragraph}"
_NON_UNIQUE_PARA_ID = "2147483648"
_OUTLINE_NAME_RE = re.compile(r"^(?:개요|Outline)\s*(\d+)$")
#: Measured TOC Command (gold contract). ContentsMake:uint:31 = the bitmask the
#: Hancom dialog emitted (title+table+figure+equation blocks); other values are
#: unmeasured, so v1 replicates the captured value verbatim.
_TOC_COMMAND = (
    "TableOfContents:set:140:ContentsMake:uint:31 ContentsStyles:wstring:0: "
    "ContentsLevel:int:{level} ContentsAutoTabRight:int:0 "
    "ContentsLeader:int:{leader} ContentsHyperlink:bool:{hyperlink}  "
)

#: ``hh:tabItem/@leader`` names indexed by the leader code the TOC Command
#: (``ContentsLeader``) and the inline ``hp:tab/@leader`` use. Hancom draws
#: ``DASH`` (code 3, the default) as the fine dotted leader of its own TOC.
_TAB_LEADER_NAMES = (
    "NONE", "SOLID", "DOT", "DASH", "DASH_DOT", "DASH_DOT_DOT", "LONG_DASH",
    "CIRCLE", "DOUBLE_SLIM", "SLIM_THICK", "THICK_SLIM", "SLIM_THICK_SLIM",
)


#: ``hp:ctrl`` children that set up the section from its first paragraph on.
_SECTION_START_CONTROLS = frozenset(
    {"colPr", "header", "footer", "pageNum", "pageNumCtrl", "pageHiding", "newNum"}
)


def _rand_id() -> str:
    return str(uuid4().int & 0x7FFFFFFF)


def _keep_section_setup_first(section: Any) -> bool:
    """Move the section setup back into the section's first paragraph.

    Paragraphs inserted in front of the one that carries ``hp:secPr`` leave the
    setup in the middle of the section, and Hancom reads a ``hp:secPr`` that is
    not in a section's first paragraph as the start of a new section: a TOC
    put at index 0 became a section of its own, followed by a page break.
    ``hp:secPr`` and the controls that
    apply from the section start (columns, header, footer, page numbering) move,
    in order, into a new leading run of the first paragraph -- where Hancom
    keeps them when it inserts a TOC at the start of a document itself.
    Returns whether anything moved.
    """
    paragraphs = [p.element for p in section.paragraphs]
    if not paragraphs or paragraphs[0].find(f"{_HP}run/{_HP}secPr") is not None:
        return False
    holder = next((p for p in paragraphs[1:] if p.find(f"{_HP}run/{_HP}secPr") is not None), None)
    if holder is None:
        return False
    first = paragraphs[0]
    setup_run = first.makeelement(f"{_HP}run", {"charPrIDRef": "0"})
    for run in holder.findall(f"{_HP}run"):
        for node in list(run):
            name = ET.QName(node).localname
            if name == "secPr" or (
                name == "ctrl" and any(ET.QName(c).localname in _SECTION_START_CONTROLS for c in node)
            ):
                if name == "secPr":
                    setup_run.set("charPrIDRef", run.get("charPrIDRef", "0"))
                run.remove(node)
                setup_run.append(node)
        if len(run) == 0 and len(holder.findall(f"{_HP}run")) > 1:
            holder.remove(run)
    first.insert(0, setup_run)
    section.mark_dirty()
    return True


def _existing_paragraph_ids(doc: HwpxDocument) -> set[str]:
    ids: set[str] = set()
    for section in doc.oxml.sections:
        for p_el in section.element.iter(f"{_HP}p"):
            pid = p_el.get("id")
            if pid:
                ids.add(pid)
    return ids


def ensure_paragraph_anchor_id(doc: HwpxDocument, paragraph: Any) -> str:
    """Make ``paragraph`` addressable as a field anchor (``?#<id>``).

    Hancom resolves TOC/CROSSREF targets by the paragraph ``id`` attribute, so
    an anchor id must be unique in the document (generated paragraphs may all
    carry the shared ``2147483648`` constant)."""
    element = paragraph.element
    pid = element.get("id")
    ids = _existing_paragraph_ids(doc)
    duplicated = pid and sum(1 for section in doc.oxml.sections
                             for p in section.element.iter(f"{_HP}p")
                             if p.get("id") == pid) > 1
    if not pid or pid == _NON_UNIQUE_PARA_ID or duplicated:
        new_id = _rand_id()
        while new_id in ids:
            new_id = _rand_id()
        element.set("id", new_id)
        pid = new_id
    return pid


def outline_heading_paragraphs(doc: HwpxDocument) -> list[tuple[Any, int, str]]:
    """Return ``(paragraph, level, text)`` for 개요/Outline-styled paragraphs."""
    levels: dict[str, int] = {}
    for style_id, style in (doc.styles or {}).items():
        name = getattr(style, "name", "") or ""
        match = _OUTLINE_NAME_RE.match(name.strip())
        if match:
            levels[str(style_id)] = int(match.group(1))
    result: list[tuple[Any, int, str]] = []
    for section in doc.sections:
        for paragraph in section.paragraphs:
            style_ref = paragraph.element.get("styleIDRef")
            if style_ref in levels and (paragraph.text or "").strip():
                result.append((paragraph, levels[style_ref], paragraph.text.strip()))
    return result


# ── low-level field emission ─────────────────────────────────────────
def _param(parent: ET.Element, kind: str, name: str, value: str, *, preserve: bool = False) -> None:
    el = ET.SubElement(parent, f"{_HP}{kind}", {"name": name})
    if preserve:
        el.set("{http://www.w3.org/XML/1998/namespace}space", "preserve")
    el.text = value


def _field_begin(run: ET.Element, *, ftype: str, field_id: str, editable: str, dirty: str) -> ET.Element:
    ctrl = ET.SubElement(run, f"{_HP}ctrl")
    begin = ET.SubElement(
        ctrl,
        f"{_HP}fieldBegin",
        {
            "id": field_id,
            "type": ftype,
            "name": "",
            "editable": editable,
            "dirty": dirty,
            "zorder": "-1",
            "fieldid": field_type_id(ftype),
            "metaTag": "",
        },
    )
    return begin


def _field_end(run: ET.Element, begin: ET.Element) -> None:
    """The end of field *begin*: its id and, as Hancom writes it, its ``fieldid``."""
    ctrl = ET.SubElement(run, f"{_HP}ctrl")
    ET.SubElement(ctrl, f"{_HP}fieldEnd", {"beginIDRef": begin.get("id", ""), "fieldid": begin.get("fieldid", "")})


def _entry_para_pr(doc: HwpxDocument, leader: int) -> str:
    """Paragraph property for TOC entries: a right tab stop at the text edge.

    Hancom lays a tab out from the paragraph's tab stops; the ``hp:tab``
    attributes are only a cache of that layout. Without a right tab stop the
    page number lands at the next default tab, right after the title.
    """
    properties = doc.oxml.sections[0].properties
    size, margins = properties.page_size, properties.page_margins
    width = size.drawn_width - margins.left - margins.right - margins.gutter
    if width <= 0:
        return "0"
    header = doc.oxml.headers[0]
    tab_pr_id = header.ensure_tab_definition(
        tab_stops=[{"pos": width, "type": "RIGHT", "leader": _TAB_LEADER_NAMES[leader]}],
        auto_tab_left=True,
    )
    return header.ensure_paragraph_format(base_para_pr_id="0", tab_pr_id_ref=tab_pr_id)


def _entry_paragraph(
    numbered_title: str,
    page: int,
    target_id: str,
    char_pr: str = "0",
    *,
    para_pr: str = "0",
    leader: int = 3,
) -> ET.Element:
    """One generated TOC entry: HYPERLINK field wrapping ``title<tab/>page``."""
    p = ET.Element(f"{_HP}p", {
        "id": _rand_id(), "paraPrIDRef": para_pr, "styleIDRef": "0",
        "pageBreak": "0", "columnBreak": "0", "merged": "0",
    })
    field_id = _rand_id()
    run1 = ET.SubElement(p, f"{_HP}run", {"charPrIDRef": char_pr})
    begin = _field_begin(run1, ftype="HYPERLINK", field_id=field_id, editable="0", dirty="1")
    params = ET.SubElement(begin, f"{_HP}parameters", {"cnt": "5", "name": ""})
    _param(params, "integerParam", "Prop", "0")
    _param(params, "stringParam", "Command", f"?#{target_id};0;1;0;")
    _param(params, "stringParam", "Category", "HWPHYPERLINK_TYPE_HWP")
    _param(params, "stringParam", "TargetType", "HWPHYPERLINK_TARGET_OUTLINE")
    _param(params, "stringParam", "DocOpenType", "HWPHYPERLINK_JUMP_CURRENTTAB")

    run2 = ET.SubElement(p, f"{_HP}run", {"charPrIDRef": char_pr})
    t = ET.SubElement(run2, f"{_HP}t")
    t.text = numbered_title
    tab = ET.SubElement(t, f"{_HP}tab", {"width": "34032", "leader": str(leader), "type": "2"})
    tab.tail = str(page)

    run3 = ET.SubElement(p, f"{_HP}run", {"charPrIDRef": char_pr})
    _field_end(run3, begin)
    return p


_COLLECTED_STYLE_ID = "0"


def _paragraph_own_text(p_el: ET.Element) -> str:
    """Text carried by the paragraph's direct runs (nested table text excluded)."""
    parts: list[str] = []
    for run in p_el.findall(f"{_HP}run"):
        for t in run.findall(f"{_HP}t"):
            parts.append("".join(t.itertext()))
    return "".join(parts)


def _inside_header_footer(p_el: ET.Element, stop: ET.Element) -> bool:
    current = p_el.getparent()
    while current is not None and current is not stop:
        if current.tag in (f"{_HP}header", f"{_HP}footer"):
            return True
        current = current.getparent()
    return False


def ensure_body_styles_not_collected(doc: HwpxDocument) -> int:
    """Route non-empty 바탕글(style 0) paragraphs onto the 본문/Body style.

    Measured ContentsStyles trap (M7): the emitted TOC Command pins
    ``ContentsStyles:wstring:0:``, so on regeneration Hancom collects every
    non-empty style-0 paragraph as a TOC entry — body text must not sit on
    style 0 while a native TOC is present (the M7 demo authored body on
    본문/style 1). Only ``styleIDRef`` is rewritten; a missing ``paraPrIDRef``
    is pinned to the 바탕글 paraPr first so the effective formatting cannot
    change. Header/footer paragraphs and empty paragraphs are left alone
    (the M7 demo's empty style-0 skeleton paragraph was measured as not
    collected). Call this BEFORE :func:`add_native_toc` so the TOC region's
    own style-0 paragraphs (gold contract) are not rerouted.

    Returns the number of rerouted paragraphs. Raises :class:`ValueError`
    when the document has no 본문/Body style to route onto, refusing to
    silently produce a TOC that would swallow the body text as entries.
    """
    body_style_id: str | None = None
    collected_para_pr = "0"
    for style_id, style in (doc.styles or {}).items():
        name = (getattr(style, "name", "") or "").strip()
        eng_name = (getattr(style, "eng_name", "") or "").strip()
        raw = getattr(style, "raw_id", None)
        resolved = str(raw if raw is not None else style_id)
        if resolved == _COLLECTED_STYLE_ID:
            para_ref = getattr(style, "para_pr_id_ref", None)
            if para_ref is not None:
                collected_para_pr = str(para_ref)
            continue
        if body_style_id is None and (name == "본문" or eng_name == "Body"):
            body_style_id = resolved
    if body_style_id is None:
        raise ValueError(
            "native TOC requires a non-collected body style: this document has "
            "no 본문/Body style to route 바탕글(style 0) body text onto, and "
            "Hancom's ContentsStyles:0 regeneration would collect that text as "
            "TOC entries (measured M7 trap)"
        )
    rerouted = 0
    for section in doc.oxml.sections:
        section_rerouted = 0
        sec_el = section.element
        for p_el in sec_el.iter(f"{_HP}p"):
            if p_el.get("styleIDRef", _COLLECTED_STYLE_ID) != _COLLECTED_STYLE_ID:
                continue
            if not _paragraph_own_text(p_el).strip():
                continue
            if _inside_header_footer(p_el, sec_el):
                continue
            if p_el.get("paraPrIDRef") is None:
                p_el.set("paraPrIDRef", collected_para_pr)
            p_el.set("styleIDRef", body_style_id)
            section_rerouted += 1
        if section_rerouted:
            section.mark_dirty()
        rerouted += section_rerouted
    return rerouted


def mark_toc_dirty(doc: HwpxDocument) -> int:
    """Set ``dirty="1"`` on every TABLEOFCONTENTS field — the measured
    re-number trigger: Hancom regenerates a dirty TOC (entries, styles, page
    numbers) when it next opens the document. Call after edits that shift
    pagination. Returns the number of fields marked."""
    count = 0
    for section in doc.oxml.sections:
        for begin in section.element.iter(f"{_HP}fieldBegin"):
            if begin.get("type") == "TABLEOFCONTENTS":
                begin.set("dirty", "1")
                count += 1
        if count:
            section.mark_dirty()
    return count


def add_native_toc(
    doc: HwpxDocument,
    *,
    at_index: int = 0,
    title: str = "<제목 차례>",
    level: int = 2,
    leader: int = 3,
    hyperlink: bool = True,
    dirty: bool | None = None,
    headings: Sequence[Any] | None = None,
) -> dict[str, Any]:
    """Insert a Hancom-native TABLEOFCONTENTS field region at ``at_index``.

    Entries are generated from ``headings`` (paragraph wrappers) or, when
    omitted, auto-detected 개요/Outline-styled paragraphs. Emitted entry page
    numbers are naive estimates; with ``dirty=True`` Hancom regenerates the
    whole region — correct entries, styles, and page numbers — on its next
    open, so the first thing a user sees is a TOC Hancom itself computed.
    Hancom regenerates it from the paragraphs it collects (see below), so a
    TOC built from explicit ``headings`` that are not outline paragraphs would
    lose its entries and links. ``dirty`` therefore defaults to ``True`` for
    auto-detected headings and to ``False`` when ``headings`` is given; pass
    it explicitly to choose. Returns a summary dict.

    Collection note (measured): Hancom collects outline-styled paragraphs and
    — via the ``ContentsStyles:wstring:0:`` command — style-0 (바탕글)
    paragraphs too; give body text a non-collected style (e.g. 본문, style 1)
    or it will appear as TOC entries after regeneration.

    Entry paragraphs get a right tab stop at the text edge of the first
    section with the ``leader`` fill (a code from 0 to 11: 0 none, 3 the
    dotted leader of Hancom's own TOC), so page numbers line up on the right.
    """
    if isinstance(leader, bool) or not 0 <= leader < len(_TAB_LEADER_NAMES):
        raise HwpxValueError(
            f"leader must be a tab leader code from 0 to {len(_TAB_LEADER_NAMES) - 1}, got {leader!r}",
            code="paragraph-tab-leader-invalid",
            context={"requested": leader, "available": f"0-{len(_TAB_LEADER_NAMES) - 1}"},
            suggestion="0 은 채움 없음, 3 은 한컴 차례의 점선이다.",
        )
    if headings is None:
        detected = outline_heading_paragraphs(doc)
    else:
        detected = [(p, 1, (p.text or "").strip()) for p in headings]
    if not detected:
        raise ValueError("no outline headings found to build a TOC from")
    if dirty is None:
        dirty = headings is None

    anchors: list[tuple[str, int, str]] = []
    for paragraph, lvl, text in detected:
        anchor = ensure_paragraph_anchor_id(doc, paragraph)
        anchors.append((anchor, lvl, text))

    section = doc.oxml.sections[0]
    toc_field_id = _rand_id()

    # opening paragraph: [ctrl fieldBegin TABLEOFCONTENTS][t title]
    open_p = ET.Element(f"{_HP}p", {
        "id": _rand_id(), "paraPrIDRef": "0", "styleIDRef": "0",
        "pageBreak": "0", "columnBreak": "0", "merged": "0",
    })
    run = ET.SubElement(open_p, f"{_HP}run", {"charPrIDRef": "0"})
    begin = _field_begin(
        run, ftype="TABLEOFCONTENTS", field_id=toc_field_id,
        editable="1", dirty="1" if dirty else "0",
    )
    params = ET.SubElement(begin, f"{_HP}parameters", {"cnt": "2", "name": ""})
    _param(params, "integerParam", "Prop", "8")
    _param(
        params, "stringParam", "Command",
        _TOC_COMMAND.format(level=level, leader=leader, hyperlink=1 if hyperlink else 0),
        preserve=True,
    )
    t = ET.SubElement(run, f"{_HP}t")
    t.text = title

    entry_para_pr = _entry_para_pr(doc, leader)
    entry_elements = [
        _entry_paragraph(f"{i}. {text}", 1, anchor, para_pr=entry_para_pr, leader=leader)
        for i, (anchor, _lvl, text) in enumerate(anchors, start=1)
    ]

    # closing paragraph: [ctrl fieldEnd]
    close_p = ET.Element(f"{_HP}p", {
        "id": _rand_id(), "paraPrIDRef": "0", "styleIDRef": "0",
        "pageBreak": "0", "columnBreak": "0", "merged": "0",
    })
    close_run = ET.SubElement(close_p, f"{_HP}run", {"charPrIDRef": "0"})
    _field_end(close_run, begin)

    section.insert_paragraphs(at_index, [open_p, *entry_elements, close_p])
    if at_index == 0:
        _keep_section_setup_first(section)
    return {
        "tocFieldId": toc_field_id,
        "entryCount": len(anchors),
        "anchors": [a for a, _l, _t in anchors],
        "cachedPagesAreEstimates": True,
    }


def add_page_crossref(
    doc: HwpxDocument,
    paragraph: Any,
    target_paragraph: Any,
    *,
    cached_page: int = 1,
) -> dict[str, Any]:
    """Append a Hancom-native page CROSSREF (상호참조 → 쪽 번호) to ``paragraph``.

    The cached result run is a best-effort estimate; Hancom recomputes CROSSREF
    caches automatically on edit/save (P0 measured on the gold pair: 2→3)."""
    target_id = ensure_paragraph_anchor_id(doc, target_paragraph)
    field_id = _rand_id()
    p_el = paragraph.element

    run1 = ET.SubElement(p_el, f"{_HP}run", {"charPrIDRef": "0"})
    begin = _field_begin(run1, ftype="CROSSREF", field_id=field_id, editable="0", dirty="0")
    params = ET.SubElement(begin, f"{_HP}parameters", {"cnt": "8", "name": ""})
    _param(params, "booleanParam", "Fiexde", "1")  # sic — Hancom's own spelling
    _param(params, "integerParam", "Prop", "0")
    _param(params, "stringParam", "Command", f"?#{target_id};5;0;0;0;")
    _param(params, "stringParam", "RefPath", f"?#{target_id};")
    _param(params, "stringParam", "RefType", "TARGET_OUTLINE")
    _param(params, "stringParam", "RefContentType", "OBJECT_TYPE_PAGE")
    _param(params, "booleanParam", "RefHyperLink", "false")
    _param(params, "stringParam", "RefOpenType", "HWPHYPERLINK_JUMP_CURRENTTAB")

    run2 = ET.SubElement(p_el, f"{_HP}run", {"charPrIDRef": "0"})
    t = ET.SubElement(run2, f"{_HP}t")
    t.text = str(cached_page)

    run3 = ET.SubElement(p_el, f"{_HP}run", {"charPrIDRef": "0"})
    _field_end(run3, begin)

    paragraph.section.mark_dirty()
    return {"fieldId": field_id, "targetId": target_id, "cachedPage": cached_page}
